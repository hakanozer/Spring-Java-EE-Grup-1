package com.decosan.erp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	public String loginControl = "";

	@GetMapping("/")
	public String login(Model model) {
		model.addAttribute("loginControl",loginControl);
		loginControl="";
		return "login";
	}

	@PostMapping("/userLogin")
	public String userLogin(Model model, @RequestParam String email, @RequestParam String password) {
		if (email.equals("ali@ali.com") && password.equals("12345")) {
			return "redirect:/dashboard";
		} else {
			loginControl = "The e-mail or password is incorrect";
			model.addAttribute("loginControl", loginControl);
			return "redirect:/";
		}

	}
}