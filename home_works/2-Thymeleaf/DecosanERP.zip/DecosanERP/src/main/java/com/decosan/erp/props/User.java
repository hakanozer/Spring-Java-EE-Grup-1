package com.decosan.erp.props;

import java.util.Date;

public class User {
	
	private int uid;
	private String name;
	private String surname;
	private String mail;
	private Date date;
}
