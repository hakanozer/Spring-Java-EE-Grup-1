package com.decosan.erp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.decosan.erp.props.Note;

@Controller
public class DashboardController {
	public String noteTitle2="";
	public String note2="";
	public String dateTime2="";
	
	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		model.addAttribute("notes", noteList());
		return "dashboard";
	}

	@PostMapping("/noteAdd")
	public String noteAdd(@RequestParam String noteTitle, @RequestParam String note, @RequestParam String dateTime) {
		noteTitle2=noteTitle;
		note2=note;
		dateTime2=dateTime;
		return "redirect:/dashboard";
	}

	public List<Note> noteList() {
		List<Note> nts = new ArrayList<>();
			Note nt = new Note();
			nt.setNid(1);
			nt.setNoteTitle(noteTitle2);
			nt.setNote(note2);
			nt.setDate(dateTime2);
			nts.add(nt);
		
		return nts;
	}
}
