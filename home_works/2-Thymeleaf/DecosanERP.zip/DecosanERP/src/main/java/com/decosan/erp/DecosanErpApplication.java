package com.decosan.erp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecosanErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecosanErpApplication.class, args);
	}

}
